
Piece trouverRoi(Grille grille,int equipe);

int roiPeutEtrePris(Piece piece,Coord coordArrive,Grille grille,int equipe);

int echecMat(Grille grille);

int echec(Coord coord,Grille grille,int equipe);